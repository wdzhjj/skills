f = lambda x : x * x

print( f(5) )

g = lambda x,y : x+y

print( g(4,5) )